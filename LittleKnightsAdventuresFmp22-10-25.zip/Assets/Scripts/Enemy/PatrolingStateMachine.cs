using UnityEngine;

public class PatrolingStateMachine : EnemySimpleStateMachine
{
    public override void EnterIdle()
    {
        
    }
    public override void UpdateIdle()
    {
        
    }
}
