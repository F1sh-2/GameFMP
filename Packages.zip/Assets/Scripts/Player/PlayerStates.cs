

public class PlayerStates 
{
   public enum State
    {
        Idle,
        Run,
        Jump,
        DoubleJump,
        WallJump,
        WallSlide,
        Dash,
        Crouch,
        Ladders,
        ignore
    }
  
}
